from graphviz import Digraph

def build_cfg(ast):
    graph = Digraph(format='png')
    graph.attr('node', shape='circle')

    def walk(node, count=0):
        node_id = f"n{count}"
        label = node.type
        if node.value is not None:
            label += f"\\n{node.value}"
        graph.node(node_id, label)

        edges = []
        for i, child in enumerate(node.children):
            child_id, sub_edges = walk(child, count * 10 + i + 1)
            edges.append((node_id, child_id))
            edges.extend(sub_edges)

        return node_id, edges

    root_id, edges = walk(ast)
    for src, dst in edges:
        graph.edge(src, dst)

    return graph

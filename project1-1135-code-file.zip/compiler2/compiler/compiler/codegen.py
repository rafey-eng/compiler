def generate_code(ast):
    if ast.type == 'assign':
        left = ast.children[0].value
        right = generate_code(ast.children[1])
        return f"{left} = {right}"
    elif ast.type == 'add':
        left = generate_code(ast.children[0])
        right = generate_code(ast.children[1])
        return f"({left} + {right})"
    
    elif ast.type == 'sub':
        left = generate_code(ast.children[0])
        right = generate_code(ast.children[1])
        return f"({left} - {right})"

    elif ast.type == 'mult':
        left = generate_code(ast.children[0])
        right = generate_code(ast.children[1])
        return f"({left} * {right})"

    elif ast.type == 'div':
        left = generate_code(ast.children[0])
        right = generate_code(ast.children[1])
        return f"({left} / {right})"
    
    elif ast.type in ['num', 'id']:
        return str(ast.value)
    else:
        raise Exception(f"Unhandled AST node type: {ast.type}")

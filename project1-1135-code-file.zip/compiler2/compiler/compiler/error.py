from colorama import Fore, init
from semantic import SemanticError  # Add this import

init(autoreset=True)

def handle(error):
    if isinstance(error, SyntaxError):
        print(f"{Fore.RED}[Syntax Error]{Fore.RESET} {error}")
    elif isinstance(error, SemanticError):
        print(f"{Fore.YELLOW}[Semantic Error]{Fore.RESET} {error}")
    else:
        print(f"{Fore.RED}[Runtime Error]{Fore.RESET} {type(error).__name__}: {error}")
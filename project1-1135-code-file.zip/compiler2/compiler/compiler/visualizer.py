from graphviz import Digraph

def visualize_ast(ast, graph=None, parent=None, node_id=0):
    if graph is None:
        graph = Digraph(format='png')
        graph.attr('node', shape='box')

    current_id = f"node{node_id}"
    label = f"{ast.type}\n{ast.value}" if ast.value is not None else ast.type
    graph.node(current_id, label)

    if parent:
        graph.edge(parent, current_id)

    for i, child in enumerate(ast.children):
        visualize_ast(child, graph, current_id, node_id * 10 + i + 1)

    return graph

class SemanticError(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(message)

def analyze(ast, defined_vars=None):
    if defined_vars is None:
        defined_vars = {}

    if ast.type == 'assign':
        var_node = ast.children[0]
        expr_node = ast.children[1]
        expr_type = analyze(expr_node, defined_vars)
        defined_vars[var_node.value] = expr_type
        return defined_vars

    elif ast.type == 'add':
        left_type = analyze(ast.children[0], defined_vars)
        right_type = analyze(ast.children[1], defined_vars)
        if left_type != right_type:
            raise SemanticError(f"Type mismatch: cannot add {left_type} and {right_type}")
        return left_type
    
    elif ast.type == 'sub':
        left_type = analyze(ast.children[0], defined_vars)
        right_type = analyze(ast.children[1], defined_vars)
        if left_type != right_type:
            raise SemanticError(f"Type mismatch: cannot subtract {right_type} from {left_type}")
        return left_type

    elif ast.type == 'mult':
    # Multiplication allows int*str (e.g., "a"*3)
        left_type = analyze(ast.children[0], defined_vars)
        right_type = analyze(ast.children[1], defined_vars)
        if left_type == 'str' and right_type != 'int':
            raise SemanticError(f"Can only multiply strings with integers")
        return left_type

    elif ast.type == 'div':
        left_type = analyze(ast.children[0], defined_vars)
        right_type = analyze(ast.children[1], defined_vars)
        if left_type != right_type:
            raise SemanticError(f"Type mismatch: cannot divide {left_type} by {right_type}")
        return 'float'  # Division always returns float

    elif ast.type == 'id':
        if ast.value not in defined_vars:
            raise SemanticError(f"Undefined variable '{ast.value}'")
        return defined_vars[ast.value]

    elif ast.type == 'num':
        return 'int'

    elif ast.type == 'str':
        return 'str'

    else:
        raise SemanticError(f"Unknown AST node type: {ast.type}")
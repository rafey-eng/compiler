import ply.yacc as yacc
from lexer import tokens, lexer
from colorama import Fore, init
from graphviz import Digraph

init(autoreset=True)

precedence = (
    ('left', 'PLUS', 'MINUS'),
    ('left', 'MULTIPLY', 'DIVIDE'),
)

class ASTNode:
    def __init__(self, node_type, children=None, value=None):
        self.type = node_type
        self.children = children or []
        self.value = value

    def to_dict(self):
        return {
            "type": self.type,
            "value": self.value,
            "children": [child.to_dict() for child in self.children]
        }

# Production rules
def p_statement_assign(p):
    'statement : ID EQUALS expression'
    p[0] = ASTNode('assign', [ASTNode('id', value=p[1]), p[3]])

def p_expression_plus(p):
    'expression : expression PLUS term'
    p[0] = ASTNode('add', [p[1], p[3]])

def p_expression_minus(p):
    'expression : expression MINUS term'
    p[0] = ASTNode('sub', [p[1], p[3]])

def p_expression_mult(p):
    'expression : expression MULTIPLY term'
    p[0] = ASTNode('mult', [p[1], p[3]])

def p_expression_div(p):
    'expression : expression DIVIDE term'
    p[0] = ASTNode('div', [p[1], p[3]])

def p_expression_term(p):
    'expression : term'
    p[0] = p[1]

def p_term_number(p):
    'term : NUMBER'
    p[0] = ASTNode('num', value=p[1])

def p_term_id(p):
    'term : ID'
    p[0] = ASTNode('id', value=p[1])

def p_term_string(p):
    'term : STRING'
    p[0] = ASTNode('str', value=p[1])

def p_error(p):
    if p:
        raise SyntaxError(f"Syntax error at '{p.value}'")
    else:
        raise SyntaxError("Syntax error at EOF")

# Initialize parser
parser = yacc.yacc()

def parse_code(code):
    """Parse input code and return AST"""
    return parser.parse(code, lexer=lexer)

def show_lalr_table():
    """Generate and display LALR parsing table (text version)"""
    try:
        # Test parsing to ensure tables are generated
        parser.parse("x = 1", lexer=lexer)
        
        with open('lalr_table.txt', 'w', encoding='utf-8') as f:
            # Write grammar rules
            f.write("Grammar Rules:\n")
            for i, p in enumerate(parser.productions[1:]):  # Skip 0 (S' -> S)
                rhs = ' '.join(p.str.split()[1:]) or 'ε'
                f.write(f"{i+1}: {p.name} -> {rhs}\n")
            
            # Write action table
            f.write("\nAction Table:\n")
            for state in sorted(parser.action.keys()):
                f.write(f"\nState {state}:\n")
                for tok in sorted(parser.action[state].keys(), key=str):
                    action = parser.action[state][tok]
                    if action > 0:
                        f.write(f"  {tok}: shift and go to state {action}\n")
                    elif action < 0:
                        prod = -action
                        rhs = ' '.join(parser.productions[prod].str.split()[1:]) or 'ε'
                        f.write(f"  {tok}: reduce using rule {prod} ({parser.productions[prod].name} -> {rhs})\n")
                    else:
                        f.write(f"  {tok}: accept\n")
            
            # Write goto table
            f.write("\nGoto Table:\n")
            for state in sorted(parser.goto.keys()):
                f.write(f"\nState {state}:\n")
                for nt in sorted(parser.goto[state].keys()):
                    f.write(f"  {nt}: state {parser.goto[state][nt]}\n")
        
        print(f"{Fore.GREEN}LALR parsing table saved to lalr_table.txt{Fore.RESET}")
    except Exception as e:
        print(f"{Fore.RED}[Error]{Fore.RESET} Could not generate LALR table: {e}")

def visualize_lalr_table():
    """Generate and visualize LALR parsing table using Graphviz"""
    try:
        # Test parsing to ensure tables are generated
        parser.parse("x = 1", lexer=lexer)
        
        # Create a new directed graph
        graph = Digraph(format='png')
        graph.attr('node', shape='plaintext')
        graph.attr(rankdir='TB')
        
        # Create the table structure for ACTION table
        with graph.subgraph(name='cluster_action') as c:
            c.attr(label='LALR Action Table')
            c.attr(rank='same')
            
            # Get all terminals including $end
            terminals = set()
            for state in parser.action:
                terminals.update(parser.action[state].keys())
            # Convert all terminal names to strings for consistent sorting
            terminals = sorted([str(t) for t in terminals])
            
            # Create table HTML-like structure
            table_label = '''<<TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
                <TR><TD COLSPAN="{}" BGCOLOR="#3498db"><B>LALR Action Table</B></TD></TR>
                <TR><TD BGCOLOR="#3498db"><B>State</B></TD>'''.format(len(terminals)+1)
            
            # Add terminal headers
            for t in terminals:
                table_label += f'<TD BGCOLOR="#3498db"><B>{t}</B></TD>'
            table_label += '</TR>'
            
            # Add rows for each state (sort states numerically)
            for state in sorted(parser.action.keys(), key=lambda x: int(x) if str(x).isdigit() else x):
                table_label += f'<TR><TD BGCOLOR="#f2f2f2"><B>{state}</B></TD>'
                for t in terminals:
                    action = parser.action[state].get(t, '') if isinstance(parser.action[state], dict) else ''
                    if isinstance(action, int):
                        if action > 0:
                            display = f's{action}'
                        elif action < 0:
                            display = f'r{-action}'
                        else:
                            display = 'acc'
                    else:
                        display = str(action)
                    table_label += f'<TD>{display}</TD>'
                table_label += '</TR>'
            
            table_label += '</TABLE>>'
            
            c.node('action_table', label=table_label)
        
        # Create the table structure for GOTO table
        with graph.subgraph(name='cluster_goto') as c:
            c.attr(label='LALR Goto Table')
            c.attr(rank='same')
            
            # Get all non-terminals
            non_terminals = set()
            for state in parser.goto:
                non_terminals.update(parser.goto[state].keys())
            non_terminals = sorted([str(nt) for nt in non_terminals])
            
            # Create table HTML-like structure
            table_label = '''<<TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
                <TR><TD COLSPAN="{}" BGCOLOR="#3498db"><B>LALR Goto Table</B></TD></TR>
                <TR><TD BGCOLOR="#3498db"><B>State</B></TD>'''.format(len(non_terminals)+1)
            
            # Add non-terminal headers
            for nt in non_terminals:
                table_label += f'<TD BGCOLOR="#3498db"><B>{nt}</B></TD>'
            table_label += '</TR>'
            
            # Add rows for each state (sort states numerically)
            for state in sorted(parser.goto.keys(), key=lambda x: int(x) if str(x).isdigit() else x):
                table_label += f'<TR><TD BGCOLOR="#f2f2f2"><B>{state}</B></TD>'
                for nt in non_terminals:
                    goto_state = parser.goto[state].get(nt, '') if isinstance(parser.goto[state], dict) else ''
                    display = str(goto_state) if goto_state else ''
                    table_label += f'<TD>{display}</TD>'
                table_label += '</TR>'
            
            table_label += '</TABLE>>'
            
            c.node('goto_table', label=table_label)
        
        # Render and save the graph
        graph.render('lalr_table', view=True)
        print(f"{Fore.GREEN}LALR parsing table visualization saved to lalr_table.png{Fore.RESET}")
        
    except Exception as e:
        print(f"{Fore.RED}[Error]{Fore.RESET} Could not generate LALR table visualization: {e}")
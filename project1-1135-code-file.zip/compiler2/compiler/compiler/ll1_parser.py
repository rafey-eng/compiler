from collections import defaultdict
from colorama import Fore, init
from graphviz import Digraph

init(autoreset=True)

class LL1Parser:
    def __init__(self, grammar):
        self.epsilon = 'ε'
        self.grammar = grammar
        self.non_terminals = set(grammar.keys())
        self.terminals = self._get_terminals()
        self.first = {}
        self.follow = {}
        self.table = defaultdict(dict)
        
    def _get_terminals(self):
        terminals = set()
        for productions in self.grammar.values():
            for prod in productions:
                for symbol in prod:
                    if symbol not in self.non_terminals and symbol != self.epsilon:
                        terminals.add(symbol)
        return terminals

    def compute_first(self):
        # Initialize first sets
        for nt in self.non_terminals:
            self.first[nt] = set()
        
        changed = True
        while changed:
            changed = False
            for nt in self.non_terminals:
                for production in self.grammar[nt]:
                    # For each symbol in the production
                    for symbol in production:
                        if symbol in self.terminals:
                            # Terminal - add to first set
                            if symbol not in self.first[nt]:
                                self.first[nt].add(symbol)
                                changed = True
                            break
                        elif symbol in self.non_terminals:
                            # Non-terminal - add its first set
                            before = len(self.first[nt])
                            self.first[nt].update(self.first[symbol] - {self.epsilon})
                            if len(self.first[nt]) > before:
                                changed = True
                            if self.epsilon not in self.first[symbol]:
                                break
                    else:
                        # Entire production can derive epsilon
                        if self.epsilon not in self.first[nt]:
                            self.first[nt].add(self.epsilon)
                            changed = True

    def compute_follow(self):
        # Initialize follow sets
        for nt in self.non_terminals:
            self.follow[nt] = set()
        
        # Start symbol gets $
        start_symbol = next(iter(self.non_terminals))
        self.follow[start_symbol].add('$')
        
        changed = True
        while changed:
            changed = False
            for nt in self.non_terminals:
                for production in self.grammar[nt]:
                    # Work through production right-to-left
                    trailer = self.follow[nt].copy()
                    for symbol in reversed(production):
                        if symbol in self.non_terminals:
                            # Update follow set for non-terminal
                            before = len(self.follow[symbol])
                            self.follow[symbol].update(trailer)
                            if len(self.follow[symbol]) > before:
                                changed = True
                            
                            # Update trailer for next symbol
                            if self.epsilon in self.first[symbol]:
                                trailer.update(self.first[symbol] - {self.epsilon})
                            else:
                                trailer = self.first[symbol].copy()
                        else:
                            # Reset trailer for terminals
                            trailer = {symbol}

    def build_table(self):
        for nt in self.non_terminals:
            for production in self.grammar[nt]:
                first_of_prod = self._get_first_of_sequence(production)
                
                # For terminals in first(production)
                for terminal in first_of_prod - {self.epsilon}:
                    self.table[nt][terminal] = production
                
                # If production can derive epsilon
                if self.epsilon in first_of_prod:
                    for terminal in self.follow[nt]:
                        self.table[nt][terminal] = production

    def _get_first_of_sequence(self, sequence):
        result = set()
        for symbol in sequence:
            if symbol in self.terminals:
                result.add(symbol)
                return result
            elif symbol in self.non_terminals:
                result.update(self.first[symbol] - {self.epsilon})
                if self.epsilon not in self.first[symbol]:
                    return result
        # If we get here, all symbols can derive epsilon
        result.add(self.epsilon)
        return result

    def visualize_table(self, filename='ll1_table'):
        """Visualize the LL(1) parsing table using Graphviz"""
        try:
            # Create a new directed graph
            graph = Digraph(format='png')
            graph.attr('node', shape='plaintext')
            graph.attr(rankdir='LR')
            
            # Create the table structure
            with graph.subgraph(name='cluster_table') as c:
                c.attr(label='LL(1) Parsing Table')
                c.attr(rank='same')
                
                # Header row with terminals
                terminals = sorted(self.terminals.union({'$'}))
                
                # Create table HTML-like structure
                table_label = '''<<TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
                    <TR><TD COLSPAN="{}" BGCOLOR="#3498db"><B>LL(1) Parsing Table</B></TD></TR>
                    <TR><TD BGCOLOR="#3498db"><B>Non-Terminal</B></TD>'''.format(len(terminals)+1)
                
                # Add terminal headers
                for t in terminals:
                    table_label += f'<TD BGCOLOR="#3498db"><B>{t}</B></TD>'
                table_label += '</TR>'
                
                # Add rows for each non-terminal
                for nt in sorted(self.non_terminals):
                    table_label += f'<TR><TD BGCOLOR="#f2f2f2"><B>{nt}</B></TD>'
                    for t in terminals:
                        production = self.table[nt].get(t, '')
                        if production == ['ε']:
                            display = '<FONT COLOR="#e74c3c">ε</FONT>'
                        else:
                            display = ' '.join(production) if production else ''
                        table_label += f'<TD>{display}</TD>'
                    table_label += '</TR>'
                
                table_label += '</TABLE>>'
                
                c.node('table', label=table_label)
            
            # Render and save the graph
            graph.render(filename, view=True)
            print(f"{Fore.GREEN}LL(1) parsing table saved to {filename}.png{Fore.RESET}")
        except Exception as e:
            print(f"{Fore.RED}[Error]{Fore.RESET} Could not generate LL(1) table: {e}")

    def check_conflicts(self):
        """Check for LL(1) conflicts in the table"""
        conflicts = []
        for nt in self.non_terminals:
            for t in self.table[nt]:
                if isinstance(self.table[nt][t], list):
                    if len(self.table[nt][t]) > 1:
                        conflicts.append((nt, t, self.table[nt][t]))
        return conflicts